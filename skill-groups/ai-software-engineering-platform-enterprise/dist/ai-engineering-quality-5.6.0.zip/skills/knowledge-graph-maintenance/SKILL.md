---
name: knowledge-graph-maintenance
description: 增量构建和校验大型工程的文件级关系图谱。
---


# 工程图谱维护

## 职责

- 将文件元数据和可验证关系写入 SQLite；
- 增量更新变更文件并删除已不存在节点；
- 保存当前 Git Commit 与更新时间；
- 按方向、深度和节点上限查询影响；
- 输出图谱健康报告。
- 为架构守卫提供变更种子、正反向消费者和受影响节点闭包；查询结果必须绑定 Git Commit 与工作区指纹。

## 渐进配置

- 零配置先从源码 import、项目引用和可验证清单增量建图，不要求人工维护全量模块表。
- `.ai/architecture/module-registry.json` 只补充受保护或边界敏感模块；`.ai/architecture/dependency-rules.json` 只写真正需要强制的依赖方向。
- `.ai/architecture/public-surface.json` 只登记跨模块API、事件、DTO、迁移、协议和共享资产；运行拓扑只补充反射、消息总线、原生绑定等静态分析无法证明的关系。
- 配置与源码冲突时报告漂移，不以配置覆盖源码事实；空的可选配置保持 advisory，不制造治理耦合。

## 约束

- 不存储源码全文；
- 不把所有关系强制解释为双向；
- 达到节点上限必须返回 `truncated: true`；
- 图谱 Commit 与当前仓库不一致时必须标记 `stale`。
- 查询被节点上限截断、公共变化无消费者或图谱过期时，不得据此宣称影响范围安全。
