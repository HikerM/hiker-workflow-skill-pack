# 04 工作区与多会话协作 5.11

本插件已经从“任务分流与 Worktree 工具”升级为大型软件工程多 Agent 控制平面，共 12 个 Skill。

## 控制平面

- **大型工程多智能体总控**：总入口，协调七角色、状态、Git、锁、验收和发布。
- **项目状态管理**：维护有界 PROJECT_STATE、CURRENT_CONTEXT、CHANGELOG、ARCHITECTURE 与机器状态；与01号有界记忆协作，避免多会话持续增重。
- **任务生命周期管理**：管理 Task ID 和 Created → Released 状态机及最小变更契约。
- **多项目组合管理**：隔离多个 Git 仓库的项目身份和上下文。
- **插件应用回执**：仅用一行中文名称展示本次实际启用的插件和 Skill。

## 执行与门禁

- **任务分流与会话规划**：按真实需求拆分浏览器端、客户端、共享后端服务、契约/数据、审核、测试、文档和合并通道。
- **多工作目录任务管理**：执行受保护分支和 Worktree 规则。
- **多智能体文件锁**：保护 Unity Scene/Prefab/ProjectSettings/meta、核心服务、migration 和 API Contract。
- **功能验收闭环**：需求、实现、测试、截图/日志、文档和状态闭环。
- **代码所有权与合并控制**：检查分支流向、Conventional Commit、冲突、锁、架构守卫和合并证据。

5.11 增加任务查询失败关闭、项目环境预检、不可变审核候选和根因假设账本。API 错误或超时不能当作“没有任务”；Review、Testing、Merge 必须消费同一个 `candidate_id`；同一问题连续两个假设被否定后停止猜测式修改并进入诊断门禁。

普通局部任务只写最小范围、不变量和测试，不要求维护全量架构配置；公共表面、受保护模块或影响半径高的变更才渐进启用消费者登记、模块规则和工程图谱。

七个角色是职责契约：Master、Planning、Developer、Review、Test、Merge、Document。它们可映射到 Codex 主任务、用户明确授权的 Subagent 或不同 Worktree；不要求每次都创建七个并行 Agent。

全局自动应用模板位于 `templates/GLOBAL_AGENTS_AI_ENGINEERING.md`。它要求会话开头显示轻量路由，并在真实加载、阶段切换或上下文恢复时显示一次去重中文应用回执；不会扩大 push、merge、部署或生产写入权限。
